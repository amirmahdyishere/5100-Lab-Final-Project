create database hotel;

